package com.app.pojos;

import javax.persistence.Entity;

@Entity
public class Admin extends BaseEntity{

}
